
GDoga Sevket Hesaplama ve Veri Kaydı Uygulaması
===============================================

📱 Balık çiftliği çalışanları için üretim, ölüm ve yem verilerini kayıt altına almak ve Excel'e aktarmak için geliştirilmiştir.

Klasör Yapısı:
- assets/: Görsel dosyalar (arka plan, balık resmi)
- app/: Uygulama ekranları (JS kodları)
- formulas/: Hesaplama fonksiyonları (adet, gram, kg)
- export/: Excel ve CSV dışa aktarma modülleri

Kurulum:
- React Native ya da Expo ortamında çalıştırılabilir.
- Kurulum detayları README içinde açıklanmıştır.

Yapım: GDoga & ChatGPT destekli
